create definer = root@localhost trigger tr_udpStockVenta
    after insert
    on detalle_venta
    for each row
BEGIN
UPDATE articulo SET stock = stock - NEW.cantidad
WHERE articulo.idarticulo = NEW.idarticulo;
END;

